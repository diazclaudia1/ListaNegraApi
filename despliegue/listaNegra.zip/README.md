# Proyecto DevOps - BlackList

### Instalación de las dependencias
   `python3 -m pip install -r requirements.txt`


### Ejecución de la API desde la raiz del proyecto
   `flask run`
